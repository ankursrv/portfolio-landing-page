1. npm install react-scroll -->CMD 
-->react-scroll is used to smooth scrolling 
2. Click Contact Button then scroll move to contact section write js code syntax
--> document.getElementById('contact').scrollIntoView({behaviour:'smooth'})
<button {onClick=()=>
(document.getElementById("contact").scrollIntoView({behaviour:'smooth'})
)}>
    Contact Us 
 </button>

 3. EmailJs 
 https://dashboard.emailjs.com/
 
 EmailJS एक सेवा है जो आपको अपनी वेबसाइट या वेब एप्लिकेशन से सीधे ईमेल भेजने की सुविधा देती है, बिना सर्वर-साइड कोड के। यह उपयोगकर्ताओं को संपर्क फॉर्म, फीडबैक फॉर्म, या किसी अन्य प्रकार के फॉर्म से ईमेल भेजने के लिए बहुत उपयोगी है।

EmailJS के फायदे:
सर्वर-लेस ईमेल सेवा: EmailJS का उपयोग करने के लिए आपको अपने स्वयं के सर्वर को कॉन्फ़िगर करने की आवश्यकता नहीं है। यह आपकी वेबसाइट से सीधे ईमेल भेजने की अनुमति देता है।
आसान सेटअप: इसका सेटअप और उपयोग करना बहुत आसान है। आप इसे कुछ सरल स्टेप्स के माध्यम से सेट कर सकते हैं।
विभिन्न टेम्पलेट्स: यह विभिन्न ईमेल टेम्पलेट्स को सपोर्ट करता है जिन्हें आप अपनी ज़रूरतों के अनुसार कस्टमाइज़ कर सकते हैं।
प्लगइन्स और इंटीग्रेशन्स: EmailJS विभिन्न जावास्क्रिप्ट फ्रेमवर्क और लाइब्रेरीज़ (जैसे React, Angular, Vue.js) के साथ संगत है।

4.Github website LInk
https://ankursrv.github.io/react-porfolio-website/